<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
namespace mod_offlinesession;
defined('MOODLE_INTERNAL') || die();

require_once($CFG->libdir.'/formslib.php');
class offlinesession_edit_form extends \moodleform {
    
    // function get_form () {
    //     return $this->_form;
    // }
    
    function definition() {
        $mform = $this->_form;
       
        global $offlinesession,$CFG;
        global $dataid;
        global $course;
        $modinfo = get_fast_modinfo($course);

        $now = getdate();
        $curryear = (int) $now['year'];
        for ($i = 1; $i <= 31; $days["$i"] = $i++);
        for ($i = 1; $i <= 12; $months["$i"] = $i++);
        for ($i = $curryear - 5; $i <= $curryear + 5; $years["$i"] = $i++);
        for ($i = 0; $i <= 23; $hours["$i"] = $i++);
        for ($i = 0; $i < 60; $i+= 5) $minutes["$i"] = sprintf("%02d", $i);
        
        $cmids["0"] = get_string('selectanactivity', 'offlinesession');
        foreach ($modinfo->cms as $cm) $cmids["$cm->id"] = $cm->name;

        if ($dataid) {
            global $offlinesession_data;
            $starttime_obj = getdate($offlinesession_data->starttime);

            $default_day   =  $starttime_obj['mday'];
            $default_month =  $starttime_obj['mon'];
            $default_year  =  $starttime_obj['year'];
            $default_starthour        = $starttime_obj['hours'];
            $default_startminute      = $starttime_obj['minutes'];
            $default_durationhour     = intval(intval($offlinesession_data->duration) / 3600);
            $default_durationminute   = intval((intval($offlinesession_data->duration) - $default_durationhour * 3600) /60);
            $default_description      = $offlinesession_data->description;
            if ($offlinesession_data->cmid) $default_cmid = $offlinesession_data->cmid;
                else $default_cmid = '0';
        } else {
            $default_day   =  $now['mday'];
            $default_month =  $now['mon'];
            $default_year  =  $curryear;
            $default_starthour      = '8';
            $default_startminute    = '00';
            $default_durationhour   = '0';
            $default_durationminute = '00';
            $default_description    = '';
            $default_cmid = '0';
        }

//-------------------------------------------------------------------------------
        // $mform->addElement('select', 'day', get_string('date'), $days);
        // $mform->setType('day', PARAM_INT);
        // $mform->addRule('day', null, 'required', null, 'client');
        // $mform->setDefault('day', $default_day);
        
        // $mform->addElement('select', 'month', '', $months);
        // $mform->setType('month', PARAM_INT);
        // $mform->setDefault('month', $default_month);
        
        // $mform->addElement('select', 'year', '', $years);
        // $mform->setType('year', PARAM_INT);
        // $mform->setDefault('year', $default_year);


        $stimearray=array();
        $stimearray[]=& $mform->createElement('select', 'day', '', $days);
        $mform->setDefault('day', $default_day);
        $mform->setType('day', PARAM_INT);
        $stimearray[]=& $mform->createElement('select', 'month', '', $months);
        $mform->setType('month', PARAM_INT);
        $mform->setDefault('month', $default_month);
        $stimearray[]=& $mform->createElement('select', 'year', '', $years);
        $mform->setType('year', PARAM_INT);
        $mform->setDefault('year', $default_year);
        $mform->addGroup( $stimearray,'timearr',get_string('date', 'offlinesession') ,' ',false);

        // $mform->addElement('date_selector', 'date', get_string('date'),$days);
        
        // $mform->addElement('select', 'starthour', get_string('starttime', 'offlinesession'), $hours);
        // $mform->setType('starthour', PARAM_INT);
        // $mform->addRule('starthour', null, 'required', null, 'client');
        // $mform->setDefault('starthour', $default_starthour);

        // $mform->addElement('select', 'startminute', '', $minutes);
        // $mform->setType('startminute', PARAM_INT);
        // $mform->setDefault('startminute', $default_startminute);

        $stimearray=array();
        $stimearray[]=& $mform->createElement('select', 'starthour', '', $hours);
        $mform->setDefault('starthour', $default_starthour);
        $mform->setType('starthour', PARAM_INT);
        $stimearray[]=& $mform->createElement('select', 'startminute', '', $minutes);
        $mform->setDefault('startminute', $default_startminute);
        $mform->setType('startminute', PARAM_INT);
        $mform->addGroup( $stimearray,'timearr',get_string('starttime', 'offlinesession') ,' ',false);

        // $mform->addElement('select', 'durationhour', get_string('duration', 'offlinesession'), $hours);
        // $mform->setType('durationhour', PARAM_INT);
        // $mform->addRule('durationhour', null, 'required', null, 'client');
        // $mform->setDefault('durationhour', $default_durationhour);

        // $mform->addElement('select', 'durationminute', '', $minutes);
        // $mform->setType('durationminute', PARAM_INT);
        // $mform->setDefault('durationminute', $default_durationminute);

           $etimearray=array();
        $etimearray[]=& $mform->createElement('select', 'durationhour', '', $hours);
        $mform->setType('durationhour', PARAM_INT);
        $mform->setDefault('durationhour', $default_durationhour);
        $etimearray[]=& $mform->createElement('select', 'durationminute', '', $minutes);
        $mform->setType('durationminute', PARAM_INT);
        $mform->setDefault('durationminute', $default_durationminute);
        $mform->addGroup( $etimearray,'timearr',get_string('duration', 'offlinesession') ,' ',false);
        // $mform->setDefault('duration', 0);
        
        // $mform->addElement('date_selector', 'assesstimefinish', get_string('date'),['days'=>$days, 'month'=>$months, 'years'=>$years]);
       
      

        $mform->addElement('textarea', 'description', get_string('description'));
        $mform->setType('description', PARAM_RAW);
        $mform->setDefault('description', $default_description);
         
        $mform->addElement(
            'filemanager',
            'file',
            get_string('file', 'offlinesession'),
            null,
            [
                'subdirs' => 0,
                'maxbytes' => $CFG->maxbytes,
                'areamaxbytes' => 10485760,
                'maxfiles' => 20,
                'accepted_types' => ['document','.png','.jpg'],
                // 'return_types' => FILE_INTERNAL | FILE_EXTERNAL,
            ]
        );

        if ($dataid) 
        $mform->addElement('hidden', 'dataid', $dataid);
        $mform->setType('dataid', PARAM_INT);
        $mform->addElement('hidden', 'offlinesessionid', $offlinesession->id);
        $mform->setType('offlinesessionid', PARAM_INT);
      
    

        $this->add_action_buttons();
    }
    
    // function validation ($data) {
      
    // }
    // Custom validation should be added here.
    function validation($data, $files) {
        $errors = parent::validation($data, $files);
        // if (!is_numeric($data['id'])) {
        //     $errors['id'] = get_string('err_numeric', 'offlinesession');
        // }
        return $errors;
    }
    
}

class MoodleOfflineSessionEditForm_Renderer extends \MoodleQuickForm_Renderer {
    function renderElement(&$element, $required, $error){
        // Make sure the element has an id.
        $element->_generateId();
        
            //adding stuff to place holders in template
        switch ($element->getName()) {
          case 'day':
          case 'starthour':
          case 'durationhour':
              $html = $this->_elementTemplates['inlinefirst'];
            break;
          case 'month':
              $html = $this->_elementTemplates['inline'];
            break;
          case 'startminute':
          case 'durationminute':
          case 'year':
              $html = $this->_elementTemplates['inlinelast'];
            break;
          default:
            if (($this->_inGroup) and !empty($this->_groupElementTemplate)) {
                // so it gets substitutions for *each* element
                $html = $this->_groupElementTemplate;
            } elseif (method_exists($element, 'getElementTemplateType')){
                $html = $this->_elementTemplates[$element->getElementTemplateType()];
            }else{
                $html = $this->_elementTemplates['default'];
            }
        }

        if ($this->_showAdvanced){
            $advclass = ' advanced';
        } else {
            $advclass = ' advanced hide';
        }
        if (isset($this->_advancedElements[$element->getName()])){
            $html =str_replace(' {advanced}', $advclass, $html);
        } else {
            $html =str_replace(' {advanced}', '', $html);
        }
        if (isset($this->_advancedElements[$element->getName()])||$element->getName() == 'mform_showadvanced'){
            $html =str_replace('{advancedimg}', $this->_advancedHTML, $html);
        } else {
            $html =str_replace('{advancedimg}', '', $html);
        }
        $html =str_replace('{id}', 'fitem_' . $element->getAttribute('id'), $html);
        $html =str_replace('{type}', 'f'.$element->getType(), $html);
        $html =str_replace('{name}', $element->getName(), $html);
        if (method_exists($element, 'getHelpButton')){
            $html = str_replace('{help}', $element->getHelpButton(), $html);
        }else{
            $html = str_replace('{help}', '', $html);

        }
        if (($this->_inGroup) and !empty($this->_groupElementTemplate)) {
            $this->_groupElementTemplate = $html;
        }
        elseif (!isset($this->_templates[$element->getName()])) {
            $this->_templates[$element->getName()] = $html;
        }

        parent::renderElement($element, $required, $error);
    }
    
    
}
class custom_renderer extends \HTML_QuickForm_Renderer_Tableless {

    // Explicitly define the property
    protected $_elementTemplates = [];

    public function __construct() {
        // Call the parent constructor
        parent::__construct();

        // Modify element templates
        $this->_elementTemplates['inline'] = "\n\t\t" .
            '<div id="{id}" class="felement finline {type}<!-- BEGIN error --> error<!-- END error -->">' .
            '<!-- BEGIN error --><span class="error">{error}</span><br /><!-- END error -->{element}</div>';

        $this->_elementTemplates['inlinelast'] = "\n\t\t" .
            '<div id="{id}" class="felement finlinelast {type}<!-- BEGIN error --> error<!-- END error -->">' .
            '<!-- BEGIN error --><span class="error">{error}</span><br /><!-- END error -->{element}</div>';

        $this->_elementTemplates['inlinefirst'] = "\n\t\t" .
            '<div id="{id}" class="pulldownIE7"></div>' .
            '<div class="fitem finlinefirst {advanced}<!-- BEGIN required --> required<!-- END required -->">' .
            '<div class="fitemtitle"><label>{label}<!-- BEGIN required -->{req}<!-- END required -->{advancedimg} {help}</label></div>' .
            '<div class="felement {type}<!-- BEGIN error --> error<!-- END error -->">' .
            '<!-- BEGIN error --><span class="error">{error}</span><br /><!-- END error -->{element}</div></div>';
    }
}
