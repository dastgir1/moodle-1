<?php

/**
 * @package    mod
 * @subpackage externship
 * @author     Domenico Pontari <fairsayan@gmail.com>
 * @copyright  2012 Institute of Tropical Medicine - Antwerp
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

require_once(dirname(dirname(dirname(__FILE__))) . '/config.php');

require_once(dirname(__FILE__) . '/lib.php');
require_once($CFG->libdir . '/filelib.php');

require_once($CFG->libdir . '/accesslib.php');
$PAGE->requires->js("/mod/externship/js/bundle.min.js");

$PAGE->requires->js("/mod/externship/js/search.js");

$id = optional_param('id', 0, PARAM_INT); // course_module ID, or
$n  = optional_param('n', 0, PARAM_INT);  // offlinesession instance ID - it should be named as the first character of the module


if ($id) {
    $cm         = $DB->get_record('course_modules', ['id' => $id]);

    $course     = $DB->get_record('course', array('id' => $cm->course), '*', MUST_EXIST);
    $externships  = $DB->get_records('externship', array('course' => $course->id));
    foreach ($externships as $externship);
} elseif ($n) {
    $externships  = $DB->get_records('externship', array('id' => $n), '*', MUST_EXIST);
    foreach ($externships as $externship);
    $course     = $DB->get_record('course', array('id' => $externship->course), '*', MUST_EXIST);
    $cm         = get_coursemodule_from_instance('externship', $externship->id, $course->id, false, MUST_EXIST);
} else {
    error('You must specify a course_module ID or an instance ID');
}

require_login($course, true, $cm);
$context = context_module::instance($id);
$see_all = has_capability('mod/externship:manageall', $context);
$modinfo = get_fast_modinfo($course);

$PAGE->set_url('/mod/externship/view.php', array('id' => $id));
$PAGE->set_title(format_string($externship->name));
$PAGE->set_heading(format_string($course->fullname));
$PAGE->set_context($context);

// Output starts here
echo $OUTPUT->header();

global $PAGE;

if (has_capability('mod/externship:canapproveentries', $context)) {
    $cmid = optional_param('id', 0, PARAM_INT); // Get the course module ID.
    $approved = get_string('approved', 'externship');
    echo "
    <ul class='nav nav-tabs'>
        <li class='nav-item border rounded'>
            <a class='nav-link' href='/mod/externship/approved-entries.php?id=$cmid&name=$externship->name'>$approved</a>
        </li>
        
     
    </ul>
    ";
}

// Assuming you pass course module ID in URL

// Get the module context
$context = context_module::instance($id);

$student_role_id = 5; // Moodle's default student role ID

if (user_has_role_assignment($USER->id, $student_role_id, $context->id)) {
    // Fetch the data from the database
    global $USER; // Ensure the global user object is accessible
    $userid = $USER->id; // Get the logged-in user's ID

    $timerecords = $DB->get_records_sql("
        SELECT cm.course, SUM(od.duration) AS total_duration
        FROM {externship_data} od
        JOIN {course_modules} cm ON od.cmid = cm.id
        WHERE cm.id = :cmid AND od.approval = 1 AND od.userid = :userid
        GROUP BY cm.course
    ", [
        'cmid' => $id,
        'userid' => $userid // Bind the logged-in user's ID
    ]);

    // Display the data in an HTML table
    if ($timerecords) {
        foreach ($timerecords as $entry) {
            $duration = ($entry->total_duration / 60) / 60;
            $total_duration = $duration . ' Hours';
            echo '<p >Externship Total Hours: </p>' . $total_duration;
        }
    } else {
        echo '<p style="">No entries approved.</p>';
    }
} else {
}

// if ($externship->intro) { // Conditions to show the intro can change to look for own settings or whatever
//     echo $OUTPUT->box(format_module_intro('externship', $externship, $cm->id), 'generalbox mod_introbox', 'externshipintro');
// }

// $content = externship_get_list($externship, $see_all);

// echo $OUTPUT->box($content, 'generalbox');

$coursemoduleid = required_param('id', PARAM_INT);
// Get the course module ID


// Check if the user is an admin
$isadmin = is_siteadmin($USER->id);

if ($isadmin) {
    // Admin: Fetch all records for the course module

    $rows = $DB->get_records('externship_data', array('cmid' => $coursemoduleid), 'starttime DESC');
} else {
    // Not admin: Fetch only records related to the current user
    $rows = $DB->get_records('externship_data', array('cmid' => $coursemoduleid, 'userid' => $USER->id), 'starttime DESC');
}
// $rows = $DB->get_records('externship_data', array('cmid' => $coursemoduleid), 'starttime DESC');
$course_module = $DB->get_record('course_modules', ['id' => $coursemoduleid]);

$externships = $DB->get_records('externship', ['course' => $course_module->course]);
foreach ($externships as $externship);

$add_new_string = get_string('addexternship', 'externship');
echo '<caption><a class="btn btn-primary rounded my-4 ml-5" href="externshipform.php?externshipid=' . $externship->id . '">' . $add_new_string . '</a></caption>';
$table = '';

if (!empty($rows)) {
    $table .= '<div class="container-fluid">';
    $table .= '<div class="row">';
    $table .= '<div class="col-md-12">';
    $table .= '<div class="card">';
    $table .= '<div class="card-header">';
    $table .= '<h3 class="text-center">Externship Record</h3>';
    $table .= ' <input type="search" class="border rounded p-2" id="search" placeholder="Search here..."/>';
    $table .= '</div>';
    $table .= '<div class="card-body">';
    $table .= '<table class="table table-striped">';
    $table .= '<thead>';
    $table .= '<tr>
                    <th scope="row">Actions</th>
                    <th scope="row">User Name</th>
                    <th scope="row">Start Time</th>
                    <th scope="row">End Time</th>
                    <th scope="row">Duration</th>
                    <th scope="row">Description</th>
                    <th scope="row">Clinic Name</th>
                    <th scope="row">Preceptor Name</th>
                    <th scope="row">Status</th>
                    <th scope="row">Comments</th>
                    <th scope="row">File</th>
                    <th scope="row">Permission</th>
                </tr>';
    $table .= '</thead>';
    $table .= '<tbody id="entrytable">';
    foreach ($rows as $row) {
        $user = $DB->get_record('user', ['id' => $row->userid]);
        $username = $user->firstname . ' ' . $user->lastname;
        $starttime = date('D d M Y H:i A', $row->starttime);
        $endtime = date('D d M Y H:i A', $row->endtime);
        $durationhour     = intval(intval($row->duration) / 3600);
        $durationminute   = intval((intval($row->duration) - $durationhour * 3600) / 60);
        $duration = $durationhour . ' Hours ' . $durationminute . ' Minutes';
        $table .= '<tr>';
        $table .= '<td>';
        if ($row->approval == 0) {


            $table .= '<a  href="externshipform.php?dataid=' . $row->id . '" class="mx-1"><i class="fa fa-gear"></i></a>';
            $table .= '<a  href="delete.php?dataid=' . $row->id . '"><i class="fa fa-remove"></i></a>';
        } else {
            if (user_has_role_assignment($USER->id, $student_role_id, $context->id)) {

                $table .= '';
            } else {

                if (has_capability('mod/externship:canapproveentries', $context)) {


                    $table .= '<a  href="externshipform.php?dataid=' . $row->id . '" ><i class="fa fa-gear "></i></a>';
                    $table .= '<a  href="delete.php?dataid=' . $row->id . '" ><i class="fa fa-remove"></i></a>';
                }
            }
        }
        $table .= '</td>';
        $table .= '<td>' . $username . '</td>';
        $table .= '<td>' . $starttime . '</td>';
        $table .= '<td>' . $endtime . '</td>';
        $table .= '<td>' . $duration . '</td>';
        $table .= '<td>' . $row->description . '</td>';
        $table .= '<td>' . $row->clinicname . '</td>';
        $table .= '<td>' . $row->preceptorname . '</td>';
        $table .= "\t\t<td>";
        if ($row->approval == 0) {
            // If $data is 0, show "Not Approved"
            $table .= 'Not Approved';
        } else {
            // If $data is not 0, show "Approved"
            $table .= 'Approved';
        }

        $table .= "</td>\n";
        $table .= "\t\t<td>";
        if (has_capability('mod/externship:canapproveentries', $context)) {
            $table .= '<form action="add_comment.php?id=' . $row->id . '&cmid=' . $cmid . '" method="post">';
            $table .= "<textarea  name='comment' class='border rounded d-block my-2' placeholder='Enter comment' rows='1' cols='14'></textarea>";
            $table .= '<button type="submit" class="btn btn-primary rounded text-truncate" style="max-width: 150px;" name="submit" value="' . $row->id . '">Add Comment</button>';

            $table .= '</form>';
            $comment = $DB->get_record('externship_data', ['id' => $row->id]);
            $table .= '' . $comment->comments . '';
        } else {
            $comment = $DB->get_record('externship_data', ['id' => $row->id]);


            $table .= "<div id='showcomment' >$comment->comments</div>";
        }
        $table .= "</td>\n";
        $cm_context = context_module::instance($cm->id);
        $fs = get_file_storage();
        // $files = $fs->get_area_files($cm_context->id , 'mod_externship', 'file',$row->id);
        $files = $fs->get_area_files($cm_context->id, 'mod_externship', 'file', $row->id, 'sortorder DESC', false);


        $download_url = '';
        foreach ($files as $file) {
            // Check if the file is not the directory placeholder ('.').
            if ($file->get_filename() !== '.') {
                // Generate the download URL using Moodle's pluginfile.php.
                $download_url = moodle_url::make_pluginfile_url(
                    $file->get_contextid(),
                    $file->get_component(),
                    $file->get_filearea(),
                    $file->get_itemid(),
                    $file->get_filepath(),
                    $file->get_filename()
                )->out();  // Convert to URL string.

                // Print the download URL or do any other processing.

            }
        }



        $table .= "\t\t<td>";
        $extension = pathinfo($download_url, PATHINFO_EXTENSION); // Get the file extension

        // Set default variables for icon and preview
        $icon = '';
        $preview = '';

        if (in_array($extension, ['png', 'jpg', 'jpeg'])) {
            $icon = $download_url; // Use the image itself as the icon
            $preview = 'preview'; // Set preview attribute for images
        } elseif ($extension == 'pdf') {
            $icon = '/mod/externship/pix/pdf.jpg'; // Path to your PDF icon
            $preview = ''; // No preview for PDF
        } elseif (in_array($extension, ['doc', 'docx'])) {
            $icon = '/mod/externship/pix/word (1).jpg'; // Path to your Word icon
            $preview = ''; // No preview for Word document
        }

        $table .= '<a href="' . $download_url . '" ' . $preview . '>
            <img src="' . $icon . '" alt="Download Image" width="50" height="50"/>
        </a>';
        $table .= "</td>\n";
        // Adding the approve button conditionally based on the capability
        $table .= "\t\t<td>";
        if (has_capability('mod/externship:canapproveentries', $context)) {
            // Show button if user has the capability
            if ($row->approval == 0) {
                // Show button if user has the capability and data is not 1
                $table .= '<button type="button" id="submit" class="rounded btn btn-primary" onclick="location.href=\'/mod/externship/externship_permission.php?dataid=' . $row->id . '\'">Approve</button>';
            } else {
                $table .= '<button type="button" id="submit" class="rounded btn btn-danger" onclick="location.href=\'/mod/externship/disapprove.php?dataid=' . $row->id . '\'">Disapprove</button>';
            }
        }
        $table .= "</td>\n";
        $table .= '</tr>';
    }
    $table .= '</tbody>';
    $table .= '</table>';
    $table .= '</div>';
    $table .= '</div>';
    $table .= '</div>';
    $table .= '</div>';
    $table .= '</div>';
    echo $table;
} else {
    echo $table = '';
}

// Finish the page
echo $OUTPUT->footer();
