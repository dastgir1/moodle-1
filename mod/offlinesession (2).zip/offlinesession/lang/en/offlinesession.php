<?php

/**
 * @package    mod
 * @subpackage offlinesession
 * @author     Domenico Pontari <fairsayan@gmail.com>
 * @copyright  2012 Institute of Tropical Medicine - Antwerp
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['modulename'] = 'offlinesession';
$string['modulenameplural'] = 'offlinesessions';
$string['modulename_help'] = 'Use the offlinesession module for... | The offlinesession module allows...';
$string['offlinesessionfieldset'] = 'Custom example fieldset';
$string['offlinesessionname'] = 'Lab Entry name';
$string['offlinesession:manageall'] = 'View Lab Entry for all users';
$string['offlinesessionname_help'] = 'This is the content of the help tooltip associated with the Lab Entry name field. Markdown syntax is supported.';
$string['offlinesession'] = 'Lab Entry';
$string['pluginadministration'] = 'Lab Entry administration';
$string['pluginname'] = 'offlinesession';

$string['date'] = 'Date';
$string['starttime'] = 'Start time';
$string['endtime'] = 'End time';
$string['duration'] = 'Duration';

$string['addofflinesession'] = 'Add a new Lab Entry';
$string['offlinesessiondataaddedsuccessfully'] = 'Lab Entry added successfully';
$string['confirmofflinesessiontobedeleted'] = 'Do you really want to delete this Lab Entry?<br />Start time: {$a->starttime}<br />Duration: {$a->duration}<br />Description: {$a->description}';
$string['unabletoaddofflinesessiondata'] = 'Unable to add Lab Entry';
$string['unabletoupdateofflinesessiondata'] = 'Unable to update Lab Entry';
$string['unabletodeleteofflinesession'] = 'Unable to delete Lab Entry';
$string['offlinesessiondataupdated'] = 'Lab Entry data updated';
$string['selectanactivity'] = 'Select an activity...';
$string['offlinesession:view'] = 'View';
$string['offlinesession:addinstance'] = 'Add instance';
$string['allcourses'] = 'All Courses';
$string['delete'] = 'Delete';
$string['approval'] = 'Approval';
$string['offlinesession:canapproveentries'] = 'Can approve entries ';
$string['approveentries'] = 'Approve Entries';
$string['action'] = 'Action';
$string['offlinesession:submit'] = 'Submit';
$string['eventeditdata'] = 'Event edit data';
$string['noofflinesessions'] = 'No Lab Entry';
$string['cmid'] = 'Course Module ID';
$string['file'] = 'File';
$string['err_numeric'] = 'error numeric';
$string['totalentries'] = 'Total Entries';
$string['status'] = 'Status';

