<?php

/**
 * @package    mod
 * @subpackage offlinesession
 * @author     Domenico Pontari <fairsayan@gmail.com>
 * @copyright  2012 Institute of Tropical Medicine - Antwerp
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */


defined('MOODLE_INTERNAL') || die();

$plugin->component = 'mod_offlinesession'; // Full name of the plugin (used for diagnostics).
$plugin->version  = 2023100909;    // The current module version (Date: YYYYMMDDXX).
// $plugin->requires = 2023100400;    // Requires this Moodle version.