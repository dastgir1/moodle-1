<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * The task that provides a complete restore of mod_offlinesession is defined here.
 *
 * @package     mod_offlinesession
 * @category    backup
 * @copyright   Copyright 2023 © PakTaleem Online Islamic School. All rights reserved.
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

/**
 * offlinesession restore task that provides all the settings and steps to perform one
 * complete restore of the activity
 */

 require_once($CFG->dirroot . '/mod/offlinesession/backup/moodle2/restore_offlinesession_stepslib.php'); // Because it exists (must)

 class restore_offlinesession_activity_task extends restore_activity_task {

    /**
     * Defines particular settings for the plugin.
     */
    protected function define_my_settings() {
        // No specific settings for the offlinesession activity.
    }

    /**
     * Define (add) particular steps this activity can have.
     */
    protected function define_my_steps() {
        // The offlinesession activity only has one structure step.
        $this->add_step(new restore_offlinesession_activity_structure_step('offlinesession_structure', 'offlinesession.xml'));
    }

    /**
     * Define the contents in the activity that must be processed by the link decoder.
     */
    public static function define_decode_contents() {
        $contents = array();

        // Make sure 'intro' field exists in your XML.
        $contents[] = new restore_decode_content('offlinesession', array('intro'), 'offlinesession');

        return $contents;
    }

    /**
     * Define the decoding rules for links belonging to the activity to be executed by the link decoder.
     */
    public static function define_decode_rules() {
        $rules = array();
    
        // Decode link to offlinesession view by module ID.
        $rules[] = new restore_decode_rule('offlinesessionVIEWBYID', '/mod/offlinesession/view.php?id=$1', 'course_module');
    
        // Decode link to the offlinesession index by course ID.
        $rules[] = new restore_decode_rule('offlinesessionINDEX', '/mod/offlinesession/index.php?id=$1', 'course');
    
        // Decode link to offlinesession file image with correct placeholders for contextid, itemid, and filename.
        $rules[] = new restore_decode_rule(
            'offlinesessionIMAGEFILE',
            '/pluginfile.php/$1/mod_offlinesession/$2/$3/$4/$5',
            array('contextid', 'component', 'filearea', 'itemid', 'filename')
        );
    
        return $rules;
    }
    
    

    /**
     * Define the restore log rules that will be applied by the restore_logs_processor when restoring offlinesession logs.
     */
    public static function define_restore_log_rules() {
        $rules = array();

        $rules[] = new restore_log_rule('offlinesession', 'add', 'view.php?id={course_module}', '{offlinesession}');
        $rules[] = new restore_log_rule('offlinesession', 'update', 'view.php?id={course_module}', '{offlinesession}');
        $rules[] = new restore_log_rule('offlinesession', 'view', 'view.php?id={course_module}', '{offlinesession}');
        $rules[] = new restore_log_rule('offlinesession', 'report', 'report.php?id={course_module}', '{offlinesession}');

        return $rules;
    }


}




