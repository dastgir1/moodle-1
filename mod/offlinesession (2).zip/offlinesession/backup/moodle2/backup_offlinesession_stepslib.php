<?php
// This file is part of Moodle - https://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <https://www.gnu.org/licenses/>.

/**
 * Backup steps for mod_offlinesession are defined here.
 *
 * @package     mod_offlinesession
 * @category    backup
 * @copyright   Copyright 2023 © PakTaleem Online Islamic School. All rights reserved.
 * @license     https://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

// More information about the backup process: {@link https://docs.moodle.org/dev/Backup_API}.
// More information about the restore process: {@link https://docs.moodle.org/dev/Restore_API}.

/**
 * Define the complete structure for backup, with file and id annotations.
 */
class backup_offlinesession_activity_structure_step extends backup_activity_structure_step {

    /**
     * Defines the structure of the resulting XML file.
     *
     * @return backup_nested_element The structure wrapped by the common 'activity' element.
     */
    protected function define_structure() {
        $userinfo = $this->get_setting_value('userinfo');

        // Define the root element describing the offlinesession instance.
        $offlinesession = new backup_nested_element('offlinesession', array('id'), array(
            'course', 'name', 'intro', 'introformat', 'timecreated', 'timemodified',
        ));

       
        $offlinesession_data = new backup_nested_element('offlinesession_data', array('id'), array(
            'offlinesessionid', 'userid', 'starttime','endtime', 'duration', 'description', 'approval', 'file','clinicname','preceptorname','comments'
        ));

        // Build the tree by adding offlinesession_data_rec as a child of offlinesession_data and offlinesession_data as a child of offlinesession.
        $offlinesession->add_child($offlinesession_data);
        // $offlinesession_data->add_child($offlinesession_data_rec);

        // Define the source table for the offlinesession instance.
        $offlinesession->set_source_table('offlinesession', array('id' => backup::VAR_ACTIVITYID));

        // If user information is included, get all relevant entries from offlinesession_data.
        if ($userinfo) {
            $offlinesession_data->set_source_sql('
                SELECT id, offlinesessionid, userid, starttime,endtime, duration, description, approval, file,clinicname,preceptorname,comments
                  FROM {offlinesession_data}
                 WHERE offlinesessionid = ?',
                array(backup::VAR_PARENTID));
        } 
        else {
            // If no user information, backup the offlinesession data without user details.
            $offlinesession_data->set_source_sql('
                SELECT id, offlinesessionid, starttime,endtime, duration, description, approval, file,clinicname,preceptorname,comments
                  FROM {offlinesession_data}
                 WHERE offlinesessionid = ?',
                array(backup::VAR_PARENTID));
        }

        // Define ID annotations to handle user data in the offlinesession_data.
        $offlinesession_data->annotate_ids('user', 'userid');

        // Define file annotations for the offlinesession intro area.
        $offlinesession->annotate_files('mod_offlinesession', 'intro', null);
        
        // Define file annotations for user-uploaded files in offlinesession_data.
        $offlinesession_data->annotate_files('mod_offlinesession', 'file', null);

        // Return the prepared activity structure for backup.
        return $this->prepare_activity_structure($offlinesession);
    }
}



