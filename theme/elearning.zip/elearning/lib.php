<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Callback implementations for elearning theme
 *
 * Documentation: {@link https://docs.moodle.org/dev/Themes}
 *
 * @package    theme_elearning
 * @copyright  2024 ghulam.dastgir@paktaleem.net
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
/**
 * Page init functions runs every time page loads.
 * @param moodle_page $page
 * @return null
 */
function theme_elearning_page_init(moodle_page $page)
{
    global $CFG, $SESSION, $PAGE, $OUTPUT;
    $page->requires->jquery();
    $pattern = theme_elearning_get_setting('patternselect');
    $pattern = !empty($pattern) ? 'pattern-' . $pattern : "pattern-default";
    $PAGE->add_body_class($pattern);
}
/**
 * Returns the main SCSS content.
 *
 * @param theme_config $theme The theme config object.
 * @return string
 */
function theme_elearning_get_main_scss_content($theme)
{
    global $CFG;

    $scss = '';
    $filename = !empty($theme->settings->preset) ? $theme->settings->preset : null;
    $fs = get_file_storage();

    $context = context_system::instance();
    if ($filename == 'default.scss') {
        // We still load the default preset files directly from the boost theme. No sense in duplicating them.                      
        $scss .= file_get_contents($CFG->dirroot . '/theme/boost/scss/preset/default.scss');
    } else if ($filename == 'plain.scss') {
        // We still load the default preset files directly from the boost theme. No sense in duplicating them.                      
        $scss .= file_get_contents($CFG->dirroot . '/theme/boost/scss/preset/plain.scss');
    } else if ($filename && ($presetfile = $fs->get_file($context->id, 'theme_elearning', 'preset', 0, '/', $filename))) {
        // This preset file was fetched from the file area for theme_elearning and not theme_boost (see the line above).                
        $scss .= $presetfile->get_content();
    } else {
        // Safety fallback - maybe new installs etc.                                                                                
        $scss .= file_get_contents($CFG->dirroot . '/theme/boost/scss/preset/default.scss');
    }

    // Pre CSS - this is loaded AFTER any prescss from the setting but before the main scss.                                        
    $pre = file_get_contents($CFG->dirroot . '/theme/elearning/scss/pre.scss');
    // Post CSS - this is loaded AFTER the main scss but before the extra scss from the setting.                                    
    $post = file_get_contents($CFG->dirroot . '/theme/elearning/scss/post.scss');

    // Combine them together.                                                                                                       
    return $pre . "\n" . $scss . "\n" . $post;
}

/**
 * Inject additional SCSS.
 *
 * @param theme_config $theme The theme config object.
 * @return string
 */
function theme_elearning_get_extra_scss($theme)
{
    return !empty($theme->settings->scss) ? $theme->settings->scss : '';
}

/**
 * Get SCSS to prepend.
 *
 * @param theme_config $theme The theme config object.
 * @return array
 */
function theme_elearning_get_pre_scss($theme)
{
    return !empty($theme->settings->scsspre) ? $theme->settings->scsspre : '';
}

/**
 * Get compiled CSS.
 *
 * @param theme_config $theme The theme config object.
 * @return string compiled CSS
 */
function theme_elearning_get_precompiled_css($theme)
{
    global $CFG;
    // By default fallback to Boost CSS.
    return file_get_contents($CFG->dirroot . '/theme/boost/style/moodle.css');
}
/**
 * Loads the CSS Styles and replace the background images.
 * If background image not available in the settings take the default images.
 *
 * @param string $css
 * @param string $theme
 * @return string
 */
function theme_elearning_process_css($css, $theme)
{
    global $OUTPUT, $CFG;
    if (!empty($theme->settings->patternselect)) {
        $pselect = $theme->settings->patternselect;
    } else {
        $pselect = '#39b3e6';
    }
    $customcss = !empty($theme->settings->customcss) ? $theme->settings->customcss : '';
    $css = theme_elearning_custom_css($css, $customcss);
    $css = theme_elearning_set_fontwww($css);
    $css = theme_elearning_get_pattern_color($css, $theme);
    $css = theme_elearning_set_slide_opacity($theme, $css);
    return $css;
}
/**
 * Get the slider obacity level from the settings and load into scss.
 * @param object $theme
 * @param string $css
 * @return string
 */
function theme_elearning_set_slide_opacity($theme, $css)
{

    if (!empty($theme->settings->slideOverlay_opacity)) {
        $opacity = $theme->settings->slideOverlay_opacity;
    } else {
        $opacity = "0";
    }
    $tag = '[[opacity]]';
    $replacement = $opacity;
    $css = str_replace($tag, $replacement, $css);
    return $css;
}
/**
 * Set elearning fontww.
 * @param string $css
 * @return string
 */
function theme_elearning_set_fontwww($css)
{
    global $CFG, $PAGE;
    if (empty($CFG->themewww)) {
        $themewww = $CFG->wwwroot . "/theme";
    } else {
        $themewww = $CFG->themewww;
    }

    $tag = '[[setting:fontwww]]';
    $theme = theme_config::load('elearning');
    $css = str_replace($tag, $themewww . '/elearning/fonts/', $css);
    return $css;
}

/**
 * Add font folder path into css file using moodle pre css method.
 * @param string $css
 * @return string
 */
function theme_elearning_pre_css_set_fontwww($css)
{
    global $CFG, $PAGE;
    if (empty($CFG->themewww)) {
        $themewww = $CFG->wwwroot . "/theme";
    } else {
        $themewww = $CFG->themewww;
    }

    $tag = '[[setting:fontwww]]';
    $theme = theme_config::load('elearning');
    $css = str_replace($tag, $themewww . '/elearning/fonts/', $css);
    return $css;
}
/**
 * Get pattern color
 * @param string $css
 * @param string $type
 * @return string
 */
function theme_elearning_get_pattern_color($css, $type = '')
{
    global $CFG;
    $patterncolors = include($CFG->dirroot . '/theme/elearning/classes/pattern_colors.php');
    $selectedpattern = theme_elearning_get_setting('patternselect');
    foreach ($patterncolors[$selectedpattern] as $key => $value) {
        $tag = '[[' . $key . ']]';
        $replacement = $value;
        $css = str_replace($tag, $replacement, $css);
    }
    return $css;
}
/**
 * Get custom css.
 * @param string $css
 * @param string $customcss
 */
function theme_elearning_custom_css($css, $customcss)
{

    $tag = '[[setting:customcss]]';
    $replacement = $customcss;
    $css = str_replace($tag, $replacement, $css);
    return $css;
}
/**
 * Functions helps to get the admin config values which are related to the
 * theme
 * @param array $setting
 * @param bool $format
 * @return bool
 */
function theme_elearning_get_setting($setting, $format = true)
{
    global $CFG;
    require_once($CFG->dirroot . '/lib/weblib.php');
    static $theme;
    if (empty($theme)) {
        $theme = theme_config::load('elearning');
    }
    if (isset($theme->settings->$setting)) {
        if (empty($theme->settings->$setting)) {
            return false;
        } else if (!$format) {
            return $theme->settings->$setting;
        } else if ($format === 'format_text') {
            return format_text($theme->settings->$setting, FORMAT_PLAIN);
        } else if ($format === 'format_html') {
            return format_text($theme->settings->$setting, FORMAT_HTML, array('trusted' => true, 'noclean' => true));
        } else {
            return format_string($theme->settings->$setting);
        }
    }
}
/**
 * Renderer the slider images.
 * @param integer $p
 * @param string $sliname
 * @return null
 */
function theme_elearning_render_slideimg($p, $sliname)
{
    global $PAGE, $OUTPUT;

    $nos = theme_elearning_get_setting('numberofslides');
    if (theme_elearning_get_setting($sliname)) {
        $slideimage = $PAGE->theme->setting_file_url($sliname, $sliname);
        return $slideimage;
    }
    return "";
}
/**
 * Returns the language values from the given lang string or key.
 * @param string $key
 * @return string
 */
function theme_elearning_lang($key = '')
{
    $pos = strpos($key, 'lang:');
    if ($pos !== false) {
        list($l, $k) = explode(":", $key);
        if (get_string_manager()->string_exists($k, 'theme_elearning')) {
            $v = get_string($k, 'theme_elearning');
            return $v;
        } else {
            return $key;
        }
    } else {
        return $key;
    }
}
/**
 * Render the current theme url
 * @return string
 */
function theme_elearning_theme_url()
{
    global $CFG, $PAGE;
    $themeurl = $CFG->wwwroot . '/theme/' . $PAGE->theme->name;
    return $themeurl;
}
/**
 * Serves any files associated with the theme settings.
 *
 * @param stdClass $course
 * @param stdClass $cm
 * @param context $context
 * @param string $filearea
 * @param array $args
 * @param bool $forcedownload
 * @param array $options
 * @return bool
 */
function theme_elearning_pluginfile($course, $cm, $context, $filearea, $args, $forcedownload, array $options = array())
{
    static $theme;
    $bgimgs = array('testimonialsbg', 'footbgimg', 'newcoursesbg', 'popularcoursesbg', 'aboutbg', 'loginbg');

    if (empty($theme)) {
        $theme = theme_config::load('elearning');
    }
    if ($context->contextlevel == CONTEXT_SYSTEM) {

        if ($filearea === 'logo') {
            return $theme->setting_file_serve('logo', $args, $forcedownload, $options);
        } else if ($filearea === 'footerlogo') {
            return $theme->setting_file_serve('footerlogo', $args, $forcedownload, $options);
        } else if ($filearea === 'style') {
            theme_elearning_serve_css($args[1]);
        } else if ($filearea === 'pagebackground') {
            return $theme->setting_file_serve('pagebackground', $args, $forcedownload, $options);
        } else if (preg_match("/slide[1-9][0-9]*image/", $filearea) !== false) {
            return $theme->setting_file_serve($filearea, $args, $forcedownload, $options);
        } else if (in_array($filearea, $bgimgs)) {
            return $theme->setting_file_serve($filearea, $args, $forcedownload, $options);
        } else {
            send_file_not_found();
        }
    } else {
        send_file_not_found();
    }
}

/**
 * Serves CSS for image file updated to styles.
 *
 * @param string $filename
 * @return string
 */
function theme_elearning_serve_css($filename)
{
    global $CFG;
    if (!empty($CFG->themedir)) {
        $thestylepath = $CFG->themedir . '/elearning/style/';
    } else {
        $thestylepath = $CFG->dirroot . '/theme/elearning/style/';
    }
    $thesheet = $thestylepath . $filename;

    $etagfile = md5_file($thesheet);
    // File.
    $lastmodified = filemtime($thesheet);
    // Header.
    $ifmodifiedsince = (isset($_SERVER['HTTP_IF_MODIFIED_SINCE']) ? $_SERVER['HTTP_IF_MODIFIED_SINCE'] : false);
    $etagheader = (isset($_SERVER['HTTP_IF_NONE_MATCH']) ? trim($_SERVER['HTTP_IF_NONE_MATCH']) : false);

    if ((($ifmodifiedsince) && (strtotime($ifmodifiedsince) == $lastmodified)) || $etagheader == $etagfile) {
        theme_elearning_send_unmodified($lastmodified, $etagfile);
    }
    theme_elearning_send_cached_css($thestylepath, $filename, $lastmodified, $etagfile);
}
/**
 * Set browser cache used in php header.
 * @param string $lastmodified
 * @param string $etag
 *
 */
function theme_elearning_send_unmodified($lastmodified, $etag)
{
    $lifetime = 60 * 60 * 24 * 60;
    header('HTTP/1.1 304 Not Modified');
    header('Expires: ' . gmdate('D, d M Y H:i:s', time() + $lifetime) . ' GMT');
    header('Cache-Control: public, max-age=' . $lifetime);
    header('Content-Type: text/css; charset=utf-8');
    header('Etag: "' . $etag . '"');
    if ($lastmodified) {
        header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $lastmodified) . ' GMT');
    }
    die;
}
/**
 * Cached css.
 * @param string $path
 * @param string $filename
 * @param integer $lastmodified
 * @param string $etag
 */
function theme_elearning_send_cached_css($path, $filename, $lastmodified, $etag)
{
    global $CFG;
    require_once($CFG->dirroot . '/lib/configonlylib.php');
    // 60 days only - the revision may get incremented quite often.
    $lifetime = 60 * 60 * 24 * 60;

    header('Etag: "' . $etag . '"');
    header('Content-Disposition: inline; filename="' . $filename . '"');
    header('Last-Modified: ' . gmdate('D, d M Y H:i:s', $lastmodified) . ' GMT');
    header('Expires: ' . gmdate('D, d M Y H:i:s', time() + $lifetime) . ' GMT');
    header('Pragma: ');
    header('Cache-Control: public, max-age=' . $lifetime);
    header('Accept-Ranges: none');
    header('Content-Type: text/css; charset=utf-8');
    if (!min_enable_zlib_compression()) {
        header('Content-Length: ' . filesize($path . $filename));
    }

    readfile($path . $filename);
    die;
}
/**
 * Returns the footer block address section values from admin configs.
 * @param string $check
 * @return string
 */
function theme_elearning_footer_address($check = "")
{
    global $PAGE;
    $value = '';
    $address = theme_elearning_get_setting('footaddress');
    $address = theme_elearning_lang($address);
    $email = theme_elearning_get_setting('footemailid');
    $email = theme_elearning_lang($email);
    $phone = theme_elearning_get_setting('footphoneno');
    $phone = theme_elearning_lang($phone);
    if (!empty($address) || !empty($email) || !empty($phone)) {
        $status = "true";
        $value = html_writer::start_tag('div', array('class' => 'footer-address-block'));

        if (!empty($address)) {
            $value .= html_writer::start_tag('div', array('class' => 'footer-address'));
            $value .= html_writer::tag('p', "<i class='fa fa-map-marker'></i>" . $address);
            $value .= html_writer::end_tag('div');
        }
        if (!empty($phone)) {
            $value .= html_writer::start_tag('div', array('class' => 'footer-phone'));
            $value .= html_writer::start_tag('p');
            $value .= "<i class='fa fa-phone-square'></i>" . get_string('phone') . ": ";
            $value .= $phone;
            $value .= html_writer::end_tag('p');
            $value .= html_writer::end_tag('div');
        }
        if (!empty($email)) {
            $value .= html_writer::start_tag('div', array('class' => 'footer-email'));
            $value .= html_writer::start_tag('p');

            $value .= "<i class='fa fa-envelope'></i>" . get_string('emailid', 'theme_elearning') . ": ";
            $value .= html_writer::link('mailto:' . $email, $email);
            $value .= html_writer::end_tag('p');
            $value .= html_writer::end_tag('div');
        }
        $value .= html_writer::end_tag('div');
    } else {
        $status = "false";
        $value = "";
    }
    if ($check == "true") {
        return $status;
    }
    return $value;
}
/**
 * Returns the HTML contents for the marketing spot1 (About us)
 * @return type|string
 */
function theme_elearning_marketingspot1()
{
    global $CFG, $PAGE;

    $status = theme_elearning_get_setting('marketingSpot1_status');
    $description = theme_elearning_get_setting('mspot1desc');
    $title = theme_elearning_lang(theme_elearning_get_setting('mspot1title'));
    $media = theme_elearning_get_setting('mspot1media', 'format_html');
    if (!empty($media)) {
        $classmedia = 'video-visible';
    } else {
        $classmedia = "";
    }
    $content = '';
    if (!empty($title)) {
        $title = explode(' ', $title);
        $title1 = (array_key_exists(0, $title)) ? $title[0] : $title;
        $title2 = array_slice($title, 1);
        $title2 = implode(' ', $title2);
    } else {
        $title1 = $title2 = "";
    }
    if (isset($status) && $status == 1) {
        $description = theme_elearning_lang($description);
        if (!empty($description) || !empty($media)) {

            if (!empty($media) && !empty($description)) {
                $hide = "display:none";
                $hide2 = "";
            } else if (!empty($media) && empty($description)) {
                $hide = "";
                $hide2 = "display:none";
            } else {
                $hide = "";
                $hide2 = "display:none";
            }
            $content .= html_writer::start_tag('div', array('class' => 'site-info'));
            $content .= html_writer::start_tag('div', array('class' => 'container-fluid'));

            $content .= html_writer::start_tag('div', array('class' => 'info-content ' . $classmedia));
            $content .= html_writer::tag('h2', html_writer::tag('b', $title1) . " " . $title2, array('style' => $hide));
            if (!empty($description)) {
                $content .= html_writer::start_tag('div', array(
                    'class' => 'info-video',
                    'style' => 'max-width:550px;float:left;'
                ));
                $content .= $media;
                $content .= html_writer::end_tag('div');
                $content .= html_writer::start_tag('div', array('class' => 'info-block'));
                $content .= html_writer::tag('h2', html_writer::tag('b', $title1) . " " . $title2, array('style' => $hide2));
                $content .= html_writer::tag('p', $description);
                $content .= html_writer::end_tag('div');
            } else {

                $content .= html_writer::start_tag('div', array(
                    'class' => 'info-video',
                    'style' => 'max-width:700px; height: 350px;'
                ));
                $content .= $media;
                $content .= html_writer::end_tag('div');
            }
            $content .= html_writer::end_tag('div');
            $content .= html_writer::end_tag('div');
            $content .= html_writer::end_tag('div');
        }
    }
    return $content;
}

/**
 * Return the html contents for the  the marketing spot2 (anytime)
 */
function theme_elearning_marketingspot2()
{
    $content = '';
    $mspot2status = theme_elearning_get_setting('marketingSpot2_status');
    $msp2title = theme_elearning_get_setting('mspot2title', 'format_html');
    $msp2title = theme_elearning_lang($msp2title);
    $msp2desc = theme_elearning_get_setting('mspot2desc', 'format_html');
    $msp2desc = theme_elearning_lang($msp2desc);
    $msp2url = theme_elearning_get_setting('mspot2url');
    $msp2urltxt = theme_elearning_get_setting('mspot2urltext', 'format_html');
    $msp2urltxt = theme_elearning_lang($msp2urltxt);
    $mspot2urltarget = theme_elearning_get_setting('mspot2urltarget');
    $target = ($mspot2urltarget == '1') ? "_blank" : "_self";
    if ($mspot2status == '1') {
        $content .= html_writer::start_tag("div", array("class" => "jumbo-viewall"));
        $content .= html_writer::start_tag("div", array("class" => "container-fluid"));
        $content .= html_writer::start_tag("div", array("class" => "inner-wrap"));
        $content .= html_writer::start_tag("div", array("class" => "desc-wrap"));
        $content .= html_writer::tag("h3", $msp2title);
        $content .= html_writer::tag("p", $msp2desc);
        $content .= html_writer::end_tag("div");
        $content .= html_writer::link($msp2url, $msp2urltxt, array('target' => $target, 'class' => 'btn-jumbo'));
        $content .= html_writer::end_tag("div");
        $content .= html_writer::end_tag("div");
        $content .= html_writer::end_tag("div");
    }
    return $content;
}
/**
 * Display Footer block Social Media links.
 *
 * @return string The Footer Social Media links are return.
 */
function theme_elearning_social_links()
{
    global $CFG;
    $totalicons = 4;
    $htmlstr = '';
    for ($i = 1; $i <= 4; $i++) {
        $iconenable = theme_elearning_get_setting('siconenable' . $i);
        $icon = theme_elearning_get_setting('socialicon' . $i);
        $iconcolor = theme_elearning_get_setting('siconbgc' . $i);
        $iconurl = theme_elearning_get_setting('siconurl' . $i);
        $iconstr = '';
        $iconsty = (empty($iconcolor)) ? '' : ' style="background: ' . $iconcolor . ';"';
        if ($iconenable == "1" && !empty($icon)) {
            $iconstr = '<li class="media0' . $i . '"' . $iconsty . '><a href="' . $iconurl . '"><i class="fa fa-' . $icon . '"></i></a></li>' . "\n";
            $htmlstr .= $iconstr;
        }
    }
    return $htmlstr;
}
/**
 * Display Footer Block Custom Links
 * @param string $menuname Footer block link name.
 * @return string The Footer links are return.
 */
function theme_elearning_generate_links($menuname = '')
{
    global $CFG, $PAGE;
    $htmlstr = '';
    $menustr = theme_elearning_get_setting($menuname);
    $menusettings = explode("\n", $menustr);
    foreach ($menusettings as $menukey => $menuval) {
        $expset = explode("|", $menuval);
        $lurl = '#';
        $ltxt = isset($expset[0]) ? $expset[0] : '';
        if (!empty($expset) && isset($expset[0]) && isset($expset[1])) {
            list($ltxt, $lurl) = $expset;
            $ltxt = trim($ltxt);
            $ltxt = theme_elearning_lang($ltxt);
            $lurl = trim($lurl);
            if (empty($ltxt)) {
                continue;
            }
            if (empty($lurl)) {
                $lurl = 'javascript:void(0);';
            }
            $pos = strpos($lurl, 'http');
            if ($pos === false) {
                $lurl = new moodle_url($lurl);
            }
        }
        $htmlstr .= '<li><a href="' . $lurl . '">' . $ltxt . '</a></li>' . "\n";
    }
    return $htmlstr;
}
/**
 * Load the logo url.
 * @param string $type
 * @return string
 */
function theme_elearning_get_logo_url($type = 'header')
{
    global $OUTPUT;
    static $theme;
    if (empty($theme)) {
        $theme = theme_config::load('elearning');
    }

    $logo = $theme->setting_file_url('logo', 'logo');
    $logo = empty($logo) ? '' : $logo;
    return $logo;
}
