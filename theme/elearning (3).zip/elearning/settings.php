<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Settings for elearning theme
 *
 * @package    theme_elearning
 * @copyright  2024 ghulam.dastgir@paktaleem.net
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

if ($ADMIN->fulltree) {

    // Since this theme is based on Boost, we can use all the strings from theme_boost.
    // Below are the example settings that you can replace with your own.

    $settings = new theme_boost_admin_settingspage_tabs('themesettingelearning', get_string('pluginname', 'theme_elearning'));
    $page = new admin_settingpage('theme_elearning_general', get_string('generalsettings', 'theme_boost'));

    //Setting for the preset, similar to the one in boost - remove/replace if not needed.
    $choices = ['default.scss' => 'default.scss', 'plain.scss' => 'plain.scss'];
    $setting = new admin_setting_configthemepreset(
        'theme_elearning/preset',
        get_string('preset', 'theme_boost'),
        get_string('preset_desc', 'theme_boost'),
        key($choices),
        $choices,
        'elearning'
    );
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    $name = 'theme_elearning/patternselect';
    $title = get_string('patternselect', 'theme_elearning');
    $description = get_string('patternselectdesc', 'theme_elearning');
    $default = 'default';
    $choices = array(
        'default' => get_string("blue", "theme_elearning"),
        '1' => get_string("green", "theme_elearning"),
        '2' => get_string("lavender", "theme_elearning"),
        '3' => get_string("red", "theme_elearning"),
        '4' => get_string("purple", "theme_elearning")
    );

    $setting = new admin_setting_configselect(
        $name,
        $title,
        $description,
        $default,
        $choices
    );
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    // Logo file setting.
    $name = 'theme_elearning/logo';
    $title = get_string('logo', 'theme_elearning');
    $description = get_string('logodesc', 'theme_elearning');
    $setting = new admin_setting_configstoredfile($name, $title, $description, 'logo');
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    // Primary menu position.
    $name = 'theme_elearning/primarymenu';
    $title = get_string('primarymenu', 'theme_elearning');
    $description = get_string('primarymenudesc', 'theme_elearning');
    $default = get_string('primary_menu', 'theme_elearning');
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $page->add($setting);

    // Course menu.
    $name = 'theme_elearning/cmenushow';
    $title = get_string('cmenushow', 'theme_elearning');
    $description = get_string(
        'cmenushowdesc',
        'theme_elearning'
    );
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Course menu position.
    $name = 'theme_elearning/cmenuPosition';
    $title = get_string('cmenuPosition', 'theme_elearning');
    $description = get_string('cmenuPosition_desc', 'theme_elearning');
    $default = '2';
    $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
    $page->add($setting);

    // This is the descriptor for Slide One.
    $name = 'theme_elearning/theme_elearning_miscellaneous';
    $heading = get_string('miscellaneous', 'theme_elearning');
    $information = "";
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    // Combo list box type.
    $name = 'theme_elearning/comboListboxType';
    $title = get_string('comboListboxType', 'theme_elearning');
    $description = get_string('comboListboxType_desc', 'theme_elearning');
    $expand = get_string('expand', 'theme_elearning');
    $collapse = get_string('collapse', 'theme_elearning');
    $default = 1;
    $choices = array(0 => $expand, 1 => $collapse);
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $page->add($setting);


    // Custom CSS file.
    $name = 'theme_elearning/customcss';
    $title = get_string('customcss', 'theme_elearning');
    $description = get_string('customcssdesc', 'theme_elearning');
    $default = '';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);
    $settings->add($page);
    // General settings end.

    /* Slideshow Settings Start */

    $page = new admin_settingpage('theme_elearning_slideshow', get_string('slideshowheading', 'theme_elearning'));
    $page->add(new admin_setting_heading(
        'theme_elearning_slideshow',
        get_string('slideshowheadingsub', 'theme_elearning'),
        format_text(get_string('slideshowdesc', 'theme_elearning'), FORMAT_MARKDOWN)
    ));

    // SlideShow Status.
    $name = 'theme_elearning/slideshowStatus';
    $title = get_string('slideshowStatus', 'theme_elearning');
    $description = get_string('slideshowStatus_desc', 'theme_elearning');
    $yes = get_string('yes');
    $no = get_string('no');
    $default = 1;
    $choices = array(1 => $yes, 0 => $no);
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $page->add($setting);

    // Auto Scroll.
    $name = 'theme_elearning/autoslideshow';
    $title = get_string('autoslideshow', 'theme_elearning');
    $description = get_string('autoslideshowdesc', 'theme_elearning');
    $yes = get_string('yes');
    $no = get_string('no');
    $default = 1;
    $choices = array(1 => $yes, 0 => $no);
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $page->add($setting);

    // Slide Show Interval.
    $name = 'theme_elearning/slideinterval';
    $title = get_string('slideinterval', 'theme_elearning');
    $description = get_string('slideintervaldesc', 'theme_elearning');
    $default = 3500;
    $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_INT);
    $page->add($setting);

    // Slide Overlay Opacity.
    $name = 'theme_elearning/slideOverlay_opacity';
    $title = get_string('slideOverlay', 'theme_elearning');
    $description = get_string('slideOverlay_desc', 'theme_elearning');
    $opacity = array();
    $opacity = array_combine(range(0, 1, 0.1), range(0, 1, 0.1));
    $setting = new admin_setting_configselect($name, $title, $description, '0.4', $opacity);
    $setting->set_updatedcallback('theme_reset_all_caches');
    $page->add($setting);

    for ($i = 1; $i <= 3; $i++) {

        // This is the descriptor for Slide One.
        $name = 'theme_elearning/slide' . $i . 'info';
        $heading = get_string(
            'slideno',
            'theme_elearning',
            array('slide' => $i)
        );
        $information = "";
        $setting = new admin_setting_heading($name, $heading, $information);
        $page->add($setting);

        // SlideShow Status.
        $name = 'theme_elearning/slide' . $i . 'status';
        $title = get_string('slideStatus', 'theme_elearning', array('slide' => $i));
        $description = get_string('slideStatus_desc', 'theme_elearning', array('slide' => $i));
        $yes = get_string('enable', 'theme_elearning');
        $no = get_string('disable', 'theme_elearning');
        $default = 1;
        $choices = array(1 => $yes, 0 => $no);
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        $page->add($setting);

        // Slide Image.
        $name = 'theme_elearning/slide' . $i . 'image';
        $title = get_string('slideimage', 'theme_elearning', array('slide' => $i));
        $description = get_string('slideimagedesc', 'theme_elearning');
        $setting = new admin_setting_configstoredfile($name, $title, $description, 'slide' . $i . 'image');
        $setting->set_updatedcallback('theme_reset_all_caches');
        $page->add($setting);

        // Slide Caption.
        $name = 'theme_elearning/slide' . $i . 'caption';
        $title = get_string('slidecaption', 'theme_elearning', array('slide' => $i));
        $description = get_string('slidecaptiondesc', 'theme_elearning');
        $default = 'lang:slidecaptiondefault';
        $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
        $page->add($setting);

        // Slide Description Text.
        $name = 'theme_elearning/slide' . $i . 'desc';
        $title = get_string('slidedesc', 'theme_elearning', array('slide' => $i));
        $description = get_string('slidedesctext', 'theme_elearning');
        $default = 'lang:slidedescdefault';
        $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_TEXT);
        $page->add($setting);

        // Slide Link text.
        $name = 'theme_elearning/slide' . $i . 'urltext1';
        $title = get_string('slideurl1text', 'theme_elearning', array('type' => "1"));
        $description = get_string('slideurl1textdesc', 'theme_elearning');
        $default = 'lang:knowmore';
        $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
        $page->add($setting);

        // Slide Url.
        $name = 'theme_elearning/slide' . $i . 'url1';
        $title = get_string('slideurl1', 'theme_elearning', array('type' => "1"));
        $description = get_string('slideurl1desc', 'theme_elearning');
        $default = 'http://www.example.com/';
        $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
        $page->add($setting);

        $name = 'theme_elearning/slide' . $i . 'urltarget1';
        $title = get_string('urltarget1', 'theme_elearning', array('type' => "1"));
        $description = get_string('urltarget_desc', 'theme_elearning', array('slide' => $i));
        $same = get_string('sameWindow', 'theme_elearning');
        $new = get_string('newWindow', 'theme_elearning');
        $default = 1;
        $choices = array(0 => $same, 1 => $new);
        $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
        $page->add($setting);

        $name = 'theme_elearning/slide' . $i . 'contFullwidth';
        $title = get_string('slideCont_full', 'theme_elearning');
        $description = get_string('slideCont_fulldesc', 'theme_elearning');
        $default = "50";
        $setting = new admin_setting_configtext($name, $title, $description, $default);
        $setting->set_updatedcallback('theme_reset_all_caches');
        $page->add($setting);


        // Slider content position.
        $name = 'theme_elearning/slide' . $i . 'contentPosition';
        $title = get_string('slidecontent', 'theme_elearning', array('slide' => $i));
        $description = get_string('slidecontentdesc', 'theme_elearning');

        $topleft = get_string("topLeft", "theme_elearning");
        $topcenter = get_string("topCenter", "theme_elearning");
        $topright = get_string("topRight", "theme_elearning");
        $centerleft = get_string("centerLeft", "theme_elearning");
        $center = get_string("center", "theme_elearning");
        $centerright = get_string("centerRight", "theme_elearning");
        $bottomleft = get_string("bottomLeft", "theme_elearning");
        $bottomcenter = get_string("bottomCenter", "theme_elearning");
        $bottomright = get_string("bottomRight", "theme_elearning");

        $default = 'centerRight';
        $choices = array(
            "topLeft" => $topleft,
            "topCenter" => $topcenter,
            "topRight" => $topright,
            "centerLeft" => $centerleft,
            "center" => $center,
            "centerRight" => $centerright,
            "bottomLeft" => $bottomleft,
            "bottomCenter" => $bottomcenter,
            "bottomRight" => $bottomright,
        );

        $setting = new admin_setting_configselect(
            $name,
            $title,
            $description,
            $default,
            $choices
        );
        $page->add($setting);
    }

    $settings->add($page);
    /* Slideshow Settings End*/
    /* Front Page Settings */
    $page = new admin_settingpage('theme_elearning_marketingspot', get_string('frontpageheading', 'theme_elearning'));
    /* Marketing Spot 1*/
    $name = 'theme_elearning_mspot1heading';
    $heading = get_string('marketingspot', 'theme_elearning') . ' 1 (' . get_string('aboutustxt', 'theme_elearning') . ')';
    $information = '';
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);
    // Marketing Spot 1 Title.

    // Marketing Spot 1 Enable or disable.
    $name = 'theme_elearning/marketingSpot1_status';
    $title = get_string('marketingSpot1_status', 'theme_elearning');
    $description = get_string('marketingSpot1_statusdesc', 'theme_elearning');
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);
    // Marketing Spot 1 Enable or disable.

    // Marketing Spot 1 Title.
    $name = 'theme_elearning/mspot1title';
    $title = get_string('title', 'theme_elearning');
    $description = get_string('mspottitledesc', 'theme_elearning', array('msno' => '1'));
    $default = 'lang:aboutus';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Marketing Spot 1 Description.
    $name = 'theme_elearning/mspot1desc';
    $title = get_string('description');
    $description = get_string('mspotdescdesc', 'theme_elearning', array('msno' => '1'));
    $default = 'lang:aboutusdesc';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_TEXT);
    $page->add($setting);

    // Marketing spot 1 Media content.
    $name = 'theme_elearning/mspot1media';
    $title = get_string('media', 'theme_elearning');
    $description = get_string('mspotmediadesc', 'theme_elearning', array('msno' => '1'));
    $default = '<div style="display:none;">image</div>
    <img src="https://res.cloudinary.com/lmsace/image/upload/v1593602097/about-img_rztwgu.jpg">';
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $page->add($setting);
    /* Marketing Spot 1*/

    /* Marketing Spot 2*/
    $name = 'theme_elearning_mspot2heading';
    $heading = get_string('marketingspot', 'theme_elearning') . ' 2 ( ' . get_string('learntitle', 'theme_elearning') . " )";
    $information = '';
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    $name = 'theme_elearning/marketingSpot2_status';
    $title = get_string('marketingSpot2_status', 'theme_elearning');
    $description = get_string('marketingSpot2_statusdesc', 'theme_elearning');
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Marketing Spot 2 Title.
    $name = 'theme_elearning/mspot2title';
    $title = get_string('title', 'theme_elearning');
    $description = get_string('mspottitledesc', 'theme_elearning', array('msno' => '2'));
    $default = 'lang:learnanytime';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Marketing Spot 2 Description.
    $name = 'theme_elearning/mspot2desc';
    $title = get_string('description');
    $description = get_string('mspotdescdesc', 'theme_elearning', array('msno' => '2'));
    $default = 'lang:learnanytimedesc';
    $setting = new admin_setting_configtextarea($name, $title, $description, $default, PARAM_TEXT);
    $page->add($setting);

    // Marketing Spot 2 Link Text.
    $name = 'theme_elearning/mspot2urltext';
    $title = get_string('button', 'theme_elearning') . ' ' . get_string('text', 'theme_elearning');
    $description = get_string('mspot2urltxtdesc', 'theme_elearning', array('msno' => '2'));
    $default = 'lang:viewallcourses';
    $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_TEXT);
    $page->add($setting);

    // Marketing Spot 2 Link.
    $name = 'theme_elearning/mspot2url';
    $title = get_string('button', 'theme_elearning') . ' ' . get_string('link', 'theme_elearning');
    $description = get_string('mspot2urldesc', 'theme_elearning');
    $default = 'http://www.example.com/';
    $setting = new admin_setting_configtext($name, $title, $description, $default, PARAM_URL);
    $page->add($setting);

    $name = 'theme_elearning/mspot2urltarget';
    $title = get_string('button', 'theme_elearning') . ' ' . get_string('target', 'theme_elearning');
    $description = get_string('mspot2urltarget_desc', 'theme_elearning');
    $same = get_string('sameWindow', 'theme_elearning');
    $new = get_string('newWindow', 'theme_elearning');
    $default = 1;
    $choices = array(0 => $same, 1 => $new);
    $setting = new admin_setting_configselect($name, $title, $description, $default, $choices);
    $page->add($setting);
    /* Marketing Spot 2*/
    $settings->add($page);
    /* Front Page Settings End */
    /* Footer Settings start */
    $page = new admin_settingpage('theme_elearning_footer', get_string('footerheading', 'theme_elearning'));

    /* Footer Block1 */
    $name = 'theme_elearning_footerblock1heading';
    $heading = get_string('footerblock', 'theme_elearning') . ' 1 ';
    $information = '';
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    $name = 'theme_elearning/footerb1_status';
    $title = get_string('activateblock', 'theme_elearning');
    $description = get_string('footerb1_statusdesc', 'theme_elearning');
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    $name = 'theme_elearning/footerbtitle1';
    $title = get_string('title', 'theme_elearning');
    $description = get_string('footerbtitledesc', 'theme_elearning');
    $default = 'lang:footerbtitle1default';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    $name = 'theme_elearning/footerdesc1';
    $title = get_string('footnote', 'theme_elearning');
    $description = get_string('footerdescription_desc', 'theme_elearning', array('blockno' => '1'));
    $default = get_string('footerblink1default', 'theme_elearning');
    $setting = new admin_setting_confightmleditor($name, $title, $description, $default);
    $page->add($setting);
    /* Footer Block1 */

    /* Footer Block2*/
    $name = 'theme_elearning_footerblock2heading';
    $heading = get_string('footerblock', 'theme_elearning') . ' 2 ';
    $information = '';
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    $name = 'theme_elearning/footerb2_status';
    $title = get_string('activateblock', 'theme_elearning');
    $description = get_string('footerb1_statusdesc', 'theme_elearning');
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    $name = 'theme_elearning/footerbtitle2';
    $title = get_string('title', 'theme_elearning');
    $description = get_string('footerbtitledesc', 'theme_elearning');
    $default = 'lang:footerbtitle2default';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    $name = 'theme_elearning/footerblink2';
    $title = get_string('links', 'theme_elearning');
    $description = get_string('footerblink_desc', 'theme_elearning', array('blockno' => '2'));
    $default = get_string('footerblink2default', 'theme_elearning');
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $page->add($setting);
    /* Footer Block2 */

    /* Footer Block3 */

    $name = 'theme_elearning_footerblock3heading';
    $heading = get_string('footerblock', 'theme_elearning') . ' 3 ';
    $information = '';
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    // Footer block 3 status.
    $name = 'theme_elearning/footerb3_status';
    $title = get_string('activateblock', 'theme_elearning');
    $description = get_string('footerb1_statusdesc', 'theme_elearning');
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Footer block title 3.
    $name = 'theme_elearning/footerbtitle3';
    $title = get_string('title', 'theme_elearning');
    $description = get_string('footerbtitledesc', 'theme_elearning');
    $default = 'lang:footerbtitle3default';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Footer block 3 link.
    $name = 'theme_elearning/footerblink3';
    $title = get_string('links', 'theme_elearning');
    $description = get_string('footerblink_desc', 'theme_elearning', array('blockno' => '3'));
    $default = get_string('footerblink3default', 'theme_elearning');
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $page->add($setting);
    /* Footer Block3 */

    /* Footer Block4 */
    $name = 'theme_elearning_footerblock4heading';
    $heading = get_string('footerblock', 'theme_elearning') . ' 4 ';
    $information = get_string('socialmediadesc', 'theme_elearning');
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    // Footer block 4 status.
    $name = 'theme_elearning/footerb4_status';
    $title = get_string('activateblock', 'theme_elearning');
    $description = get_string('footerb1_statusdesc', 'theme_elearning');
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Footer block 4 Title.
    $name = 'theme_elearning/footerbtitle4';
    $title = get_string('title', 'theme_elearning');
    $description = get_string('footerbtitledesc', 'theme_elearning');
    $default = 'lang:footerbtitle4default';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Footer Address.
    $name = 'theme_elearning/footaddress';
    $title = get_string('address', 'theme_elearning');
    $description = get_string('address_desc', 'theme_elearning');
    $default = get_string('defaultaddress', 'theme_elearning');
    $setting = new admin_setting_configtextarea($name, $title, $description, $default);
    $page->add($setting);

    // Footer Email Id.
    $name = 'theme_elearning/footemailid';
    $title = get_string('emailid', 'theme_elearning');
    $description = '';
    $default = get_string('defaultemailid', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Footer phone number.
    $name = 'theme_elearning/footphoneno';
    $title = get_string('phoneno', 'theme_elearning');
    $description = '';
    $default = get_string('defaultphoneno', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Enable / Disable social media icon 1.
    $name = 'theme_elearning/siconenable1';
    $title = get_string('enable', 'theme_elearning') . ' ' . get_string('socialicon', 'theme_elearning') . ' 1 ';
    $description = '';
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 1 - name.
    $name = 'theme_elearning/socialicon1';
    $title = get_string('socialicon', 'theme_elearning') . ' 1 ';
    $description = get_string('socialicondesc', 'theme_elearning');
    $default = get_string('socialicon1default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 1 - Background color.
    $name = 'theme_elearning/siconbgc1';
    $title = get_string('socialicon', 'theme_elearning') . ' 1 ' . get_string('bgcolor', 'theme_elearning');
    $description = get_string('siconbgcdesc', 'theme_elearning');
    $default = get_string('siconbgc1default', 'theme_elearning');
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $page->add($setting);

    // Social Media Icon Url 1.
    $name = 'theme_elearning/siconurl1';
    $title = get_string('socialicon', 'theme_elearning') . ' 1 ' . get_string('url', 'theme_elearning');
    $description = get_string('siconurldesc', 'theme_elearning');
    $default = get_string('siconurl1default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Enable / Disable social media icon 2.
    $name = 'theme_elearning/siconenable2';
    $title = get_string('enable', 'theme_elearning') . ' ' . get_string('socialicon', 'theme_elearning') . ' 2 ';
    $description = '';
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 2 - name.
    $name = 'theme_elearning/socialicon2';
    $title = get_string('socialicon', 'theme_elearning') . ' 2 ';
    $description = get_string('socialicondesc', 'theme_elearning');
    $default = get_string('socialicon2default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 2 - Background color.
    $name = 'theme_elearning/siconbgc2';
    $title = get_string('socialicon', 'theme_elearning') . ' 2 ' . get_string('bgcolor', 'theme_elearning');
    $description = get_string('siconbgcdesc', 'theme_elearning');
    $default = get_string('siconbgc2default', 'theme_elearning');
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $page->add($setting);

    // Social Media Icon Url 2.
    $name = 'theme_elearning/siconurl2';
    $title = get_string('socialicon', 'theme_elearning') . ' 2 ' . get_string('url', 'theme_elearning');
    $description = get_string('siconurldesc', 'theme_elearning');
    $default = get_string('siconurl2default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Enable / Disable social media icon 3.
    $name = 'theme_elearning/siconenable3';
    $title = get_string('enable', 'theme_elearning') . ' ' . get_string('socialicon', 'theme_elearning') . ' 3 ';
    $description = '';
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 3 - name.
    $name = 'theme_elearning/socialicon3';
    $title = get_string('socialicon', 'theme_elearning') . ' 3 ';
    $description = get_string('socialicondesc', 'theme_elearning');
    $default = get_string('socialicon3default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 3 - Background color.
    $name = 'theme_elearning/siconbgc3';
    $title = get_string('socialicon', 'theme_elearning') . ' 3 ' . get_string('bgcolor', 'theme_elearning');
    $description = get_string('siconbgcdesc', 'theme_elearning');
    $default = get_string('siconbgc3default', 'theme_elearning');
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $page->add($setting);

    // Social Media Icon Url 3.
    $name = 'theme_elearning/siconurl3';
    $title = get_string('socialicon', 'theme_elearning') . ' 3 ' . get_string('url', 'theme_elearning');
    $description = get_string('siconurldesc', 'theme_elearning');
    $default = get_string('siconurl3default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Enable / Disable social media icon 4.
    $name = 'theme_elearning/siconenable4';
    $title = get_string('enable', 'theme_elearning') . ' ' . get_string('socialicon', 'theme_elearning') . ' 4 ';
    $description = '';
    $default = 1;
    $setting = new admin_setting_configcheckbox($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 4 - name.
    $name = 'theme_elearning/socialicon4';
    $title = get_string('socialicon', 'theme_elearning') . ' 4 ';
    $description = get_string('socialicondesc', 'theme_elearning');
    $default = get_string('socialicon4default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    // Social media icon 4 - Background color.
    $name = 'theme_elearning/siconbgc4';
    $title = get_string('socialicon', 'theme_elearning') . ' 4 ' . get_string('bgcolor', 'theme_elearning');
    $description = get_string('siconbgcdesc', 'theme_elearning');
    $default = get_string('siconbgc4default', 'theme_elearning');
    $previewconfig = null;
    $setting = new admin_setting_configcolourpicker($name, $title, $description, $default, $previewconfig);
    $page->add($setting);

    // Social Media Icon Url 4.
    $name = 'theme_elearning/siconurl4';
    $title = get_string('socialicon', 'theme_elearning') . ' 4 ' . get_string('url', 'theme_elearning');
    $description = get_string('siconurldesc', 'theme_elearning');
    $default = get_string('siconurl4default', 'theme_elearning');
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);
    /* Footer Block4 */

    // Copyright.
    $name = 'theme_elearning_copyrightheading';
    $heading = get_string('copyrightheading', 'theme_elearning');
    $information = '';
    $setting = new admin_setting_heading($name, $heading, $information);
    $page->add($setting);

    // Copyright setting.
    $name = 'theme_elearning/copyright';
    $title = get_string('copyright', 'theme_elearning');
    $description = get_string('copyrightdesc', 'theme_elearning');
    $default = 'lang:copyrightdefault';
    $setting = new admin_setting_configtext($name, $title, $description, $default);
    $page->add($setting);

    $settings->add($page);
    /* Footer Settings end */
}
