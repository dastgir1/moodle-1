// Search functionality
document.getElementById('search').addEventListener('keyup', function() {
    var searchText = this.value.toLowerCase(); // Get the search input and convert to lowercase

    // Get all rows in the externship_list_table
    var rows = document.querySelectorAll('#entrytable tr');
    rows.forEach(function(row) {
        // Check if the row contains the search text
        var rowText = row.textContent.toLowerCase();
        if (rowText.indexOf(searchText) > -1) {
            row.style.display = ''; // Show the row
        } else {
            row.style.display = 'none'; // Hide the row
        }
    });
});