<?php

/**
 * @package    mod
 * @subpackage offlinesession
 * @author     Domenico Pontari <fairsayan@gmail.com>
 * @copyright  2012 Institute of Tropical Medicine - Antwerp
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
global $PAGE;
defined('MOODLE_INTERNAL') || die();
require_once(dirname(__FILE__).'/../../lib/outputrenderers.php');
require_once(__DIR__.'/../../config.php');
$PAGE->requires->js('/mod/offlinesession/js/script.js');
/**
 * 
 * @param object $offlinesession
 * @param boolean $see_all
 * @param boolean $editing
 */
function offlinesession_get_list ($offlinesession, $see_all, $editing = true) {
    global $OUTPUT;
    global $DB;
    global $USER;
    
    $add_new_string = get_string('addofflinesession', 'offlinesession');
    $first_row = true;
    $result = <<<EOD
<table id="offlinesession_list_table" cellpadding="5" rules="rows" frame="below">
    <col width="50" />
    <caption><a href="edit.php?offlinesessionid=$offlinesession->id">$add_new_string</a></caption>

EOD;
    $rows = $DB->get_records('offlinesession_data', array('offlinesessionid' => $offlinesession->id), 'starttime DESC');
    if (empty($rows))
        return "<div style=\"text-align:center\"><a href=\"edit.php?offlinesessionid=$offlinesession->id\">$add_new_string</a></div>";
    foreach ($rows as $row) {
        if ((!$see_all) && ($USER->id != $row->userid)) continue;
        if ($first_row) $result .= offlinesession_get_list_table_title ($row, $editing);
        $result .= offlinesession_get_list_table_row ($row, $editing);
        $first_row = false;
    }
    $result .= "</table>\n";
    return $result;
}

function offlinesession_get_list_table_title ($row, $editing) {
    $result = "\t<tr>\n";
    if ($editing) $result .= "\t\t<th></th>\n"; // editing cell title: blank
    foreach ($row as $name => $data) {
        if (in_array($name, array('id', 'offlinesessionid'))) continue;
        switch ($name){
           
            case 'userid':
                $result .= "\t\t<th>" . get_string("user") . "</th>\n";
                break;
            case 'cmid':
                $result .= "\t\t<th>" . get_string("cmid",'offlinesession') . "</th>\n";
                break;
            case 'description':
                $result .= "\t\t<th>" . get_string("description") . "</th>\n";
                break;
            default:
                $result .= "\t\t<th>" . get_string($name, 'offlinesession') . "</th>\n";
        }
    }
    $result .= "\t\t<th>" . get_string('status', 'offlinesession') . "</th>\n";
    $result .= "\t</tr>\n";
    return $result;
}

function offlinesession_get_list_table_row($row, $editing) {
    global $OUTPUT, $USER, $COURSE, $DB, $modinfo;

    // Get cmid and course id
    $cmid = optional_param('id', 0, PARAM_INT);
    $courseid = $DB->get_record_sql("SELECT course FROM {course_modules} WHERE id = ?", array($cmid));

    // Get course context
    $context = context_course::instance($courseid->course);

    // Start building the table row
    $result = "\t<tr>\n";
    
    // If editing is enabled, show edit and delete icons
    if ($editing) {
        $result .= "\t\t<td>";
        // $result .= '<a href=""><input class="form-check-input" type="checkbox" name="checkbox" value="' . $row->id . '" ></a>';
        $result .= '<a href="edit.php?dataid=' . $row->id . '" class="mx-1"><i class="fa fa-gear"></i></a>';
        $result .= '<a href="delete.php?dataid=' . $row->id . '"><i class="fa fa-remove"></i></a>';
       
        $result .= "</td>\n";
      
    }

    // Loop through the row data
    foreach ($row as $name => $data) {
        if (in_array($name, array('id', 'offlinesessionid'))) continue;
        switch ($name) {
            
            case 'userid':
                $user = $DB->get_record('user', array('id' => $data));
                $result .= "\t\t<td>" . fullname($user) . "</td>\n";
                break;
            case 'starttime':
                $date = userdate($data);
                $result .= "\t\t<td>$date</td>\n";
                break;
            case 'duration':
                $date = format_time($data);
                $result .= "\t\t<td>$date</td>\n";
                break;
            // case 'cmid':
            //     $modname = $data !== NULL ? $modinfo->cms[$data]->name : '';
            //     $result .= "\t\t<td>$modname</td>\n";
            //     break;
           
            default:
                $result .= "\t\t<td>$data</td>\n";
               
               
        }
    }

    // Adding the approval status (Approved / Not Approved)
    $result .= "\t\t<td>";
    if ($row->approval == 0) {
        // If $data is 0, show "Not Approved"
        $result .= 'Not Approved';
    } else {
        // If $data is not 0, show "Approved"
        $result .= 'Approved';
    }
    $result .= "</td>\n";

    // Adding the approve button conditionally based on the capability
    $result .= "\t\t<td>";
    if (has_capability('mod/offlinesession:canapproveentries', $context)) {
        // Show button if user has the capability
        if ($row->approval == 0) {
            // Show button if user has the capability and data is not 1
            $result .= '<button type="button" id="submit" class="rounded" onclick="location.href=\'/mod/offlinesession/offlinesession_permission.php?dataid='.$row->id.'\'">Approved</button>';
        }else{
            $result .= '<button type="button" id="submit" class="rounded" onclick="location.href=\'/mod/offlinesession/disapprove.php?dataid='.$row->id.'\'">Disapprove</button>';
        }
        
    }
    $result .= "</td>\n";
  
 
    
    // Close the table row
    
    $result .= "\t</tr>\n";
    return $result;
}



