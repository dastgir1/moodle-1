<?php
// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * English language pack for elearning
 *
 * @package    theme_elearning
 * @category   string
 * @copyright  2024 ghulam.dastgir@paktaleem.net
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();


$string['pluginname'] = 'elearning';
$string['advancedsettings'] = 'Advanced settings';
// The brand colour setting.                                                                                                        
$string['brandcolor'] = 'Brand colour';
// The brand colour setting description.                                                                                            
$string['brandcolor_desc'] = 'The accent colour.';
// A description shown in the admin theme selector.                                                                                 
$string['choosereadme'] = 'Theme elearning is a child theme of Boost. It adds the ability to upload background elearnings.';
// Name of the settings pages.                                                                                                      
$string['configtitle'] = 'elearning settings';
// Name of the first settings tab.                                                                                                  
$string['generalsettings'] = 'General settings';
// The name of our plugin.                                                                                                          

// Preset files setting.                                                                                                            
$string['presetfiles'] = 'Additional theme preset files';
// Preset files help text.                                                                                                          
$string['presetfiles_desc'] = 'Preset files can be used to dramatically alter the appearance of the theme. See <a href=https://docs.moodle.org/dev/Boost_Presets>Boost presets</a> for information on creating and sharing your own preset files, and see the <a href=http://moodle.net/boost>Presets repository</a> for presets that others have shared.';
// Preset setting.                                                                                                                  
$string['preset'] = 'Theme preset';
// Preset help text.                                                                                                                
$string['preset_desc'] = 'Pick a preset to broadly change the look of the theme.';
// Raw SCSS setting.                                                                                                                
$string['rawscss'] = 'Raw SCSS';
// Raw SCSS setting help text.                                                                                                      
$string['rawscss_desc'] = 'Use this field to provide SCSS or CSS code which will be injected at the end of the style sheet.';
// Raw initial SCSS setting.                                                                                                        
$string['rawscsspre'] = 'Raw initial SCSS';
// Raw initial SCSS setting help text.                                                                                              
$string['rawscsspre_desc'] = 'In this field you can provide initialising SCSS code, it will be injected before everything else. Most of the time you will use this setting to define variables.';
// We need to include a lang string for each block region.                                                                          
$string['region-side-pre'] = 'Right';
$string['viewall'] = 'View all';
$string['slidecaption'] = 'Title (Slide #{$a->slide})';
$string['slidecaptiondefault'] = 'THE BEST SOLUTION';
$string['slidecaptiondesc'] = 'Enter the title for your slide as plain text or lang:language_key for multi-lingual support.
<br/>You can find the theme language keys here : /theme/elearning/lang/en/theme_elearning.php';
$string['slideimage'] = ' Image (Slide #{$a->slide})';
$string['slideimagedesc'] = 'Upload the image you would like to display as the background image of the slide. The Recommended image size width=1600px and height=1080px ';
$string['slidedesc'] = ' Description(Slide #{$a->slide})';
$string['slidedesctext'] = 'Enter the description for your slide as plain text or lang:language_key for multi-lingual support.<br>
 You can find the theme language keys here: /theme/elearning/lang/en/theme_elearning.php';
$string['slidedescdefault'] = 'Education on awesome unique moodle theme.';
$string['slideno'] = 'Slide #{$a->slide}';
$string['slidenodesc'] = 'Enter the settings for slide {$a->slide}.';
$string['slideStatus'] = ' Status (Slide #{$a->slide})';
$string['slideStatus_desc'] = 'Choose “Disable” if you don’t want to show this slide on homepage slider.';
$string["slideshowStatus"] = "Show homepage slider";
$string["slideshowStatus_desc"] = "Choose “No” if you don’t want an image slider on your home page.";
$string['enable'] = "Enable";
$string['disable'] = "Disable";
$string['slideshowdesc'] = 'The homepage slider will allow you to promote important elements of your site; you have to upload at least one slide image to make the slideshow appear. Slide title, description and button are optional. Use larger images for best results, the slider will crop your images to fit the height and width of the slideshow. If you use too small images it won’t work correctly.';
$string['slideinterval'] = 'Pause Time';
$string['slideintervaldesc'] = 'Use this option to set the pause or wait time between each slide change in the slideshow. Value is in milliseconds (i.e 1 second = 1000 milliseconds)';
$string['slideshowheading'] = 'Homepage slider';
$string['slideshowheadingsub'] = 'SLIDER OPTIONS';
$string['slideurl1'] = 'Button 1 URL';
$string['slideurl1desc'] = 'Use this option to set the link for first button of the slide.';
$string['slideurl2'] = 'Button 2 URL';
$string['slideurl2desc'] = 'Use this option to set the link for second button of the slide.';
$string['autoslideshow'] = 'Auto play';
$string['autoslideshowdesc'] = 'Use this option to scroll slides automatically after page load.';
$string["slideOverlay"] = "Overlay opacity";
$string["slideOverlay_desc"] = "Use this option to set the opacity level,default value for this option is 0.4";
$string['slideurl1text'] = 'Button 1 Text';
$string['slideurl1textdesc'] = 'Use this option to set the text for first button of the slide. If you do not want to have button on your slide set this option to blank.<br> Enter the button text as plain text or lang:language_key for multi-lingual support.<br> You can find the theme language keys here: /theme/enlightlite/lang/en/theme_enlightlite.php';
$string["urltarget1"] = "Button 1 Target";
$string["urltarget_desc"] = "Set this option to <i>New Window</i> if you want to open the URL in a new tab.";
$string["sameWindow"] = "Same Window";
$string["newWindow"] = "New Window";
$string["slideCont_full"] = "Content Width";
$string["slideCont_fulldesc"] = "Use this option to set the content width for the slide. This width will be calculated as a percentage of main grid width. Default value for this option is 50%.";
$string['slidecontent'] = 'Content position (Slide #{$a->slide})';
$string['slidecontentdesc'] = "Use this option to set the location of slide title, description and button in the slide.";
$string["topLeft"] = "TopLeft";
$string["topCenter"] = "TopCenter";
$string["topRight"] = "TopRight";
$string["centerLeft"] = "CenterLeft";
$string["center"] = "Center";
$string["centerRight"] = "CenterRight";
$string["bottomLeft"] = "BottomLeft";
$string["bottomCenter"] = "BottomCenter";
$string["bottomRight"] = "BottomRight";
$string['generallogo_menu'] = "COLOR SCHEMES, HEADER STYLES, LOGO & MENUS";
$string['patternselect'] = 'Choose website color scheme';
$string['patternselectdesc'] = 'Select the color scheme you want to have for your site.';
$string['lavender'] = "Lavender";
$string['blue'] = "Blue";
$string['purple'] = "Purple";
$string['red'] = "Red";
$string['green'] = "Green";
$string['default'] = "Default";
$string['logo'] = 'Logo';
$string['logodesc'] = 'Upload logo image for your website.<br> The image should be 50px high and any reasonable width (minimum:235px) that suits.';
$string['primarymenu'] = "Primary menu items";
$string['primarymenudesc'] = "You can configure a primary menu here to be shown by themes. Each line consists of some menu text, a link URL (optional), a tooltip title (optional) and a language code or comma-separated list of codes (optional, for displaying the line to users of the specified language only), separated by pipe characters. Lines starting with a hyphen will appear as menu items in the previous top level menu, and dividers can be used by adding a line of one or more # characters where desired. <br>
";
$string['cmenushow'] = 'Enable courses mega menu';
$string['toggleslideshow'] = 'Slide show display';
$string['toggleslideshowdesc'] = 'Choose if you wish to hide or show the slide show.';
$string['numberofslides'] = 'Number of slides';
$string['numberofslides_desc'] = 'Number of slides on the slider.';
$string['cmenushowdesc'] = 'Use this setting to show or hide the appearance of ”Courses Mega Menu” in primary menus.';
$string["cmenuPosition"] = "Courses mega menu position";
$string["cmenuPosition_desc"] = "Use this setting to set position of the courses mega menu in primary menus.";
$string['miscellaneous'] = "MISCELLANEOUS ITEMS";
$string["comboListboxType"] = 'Combo list display style';
$string["comboListboxType_desc"] = 'Select a display style for combo list block.';
$string['customcss'] = 'Custom CSS';
$string['customcssdesc'] = 'Use this field to provide SCSS or CSS code which will be injected at the end of the style sheet.';
$string['primary_menu'] = "Home|#";
$string["expand"] = "Expanded";
$string["collapse"] = "Collapsed";
$string['frontpageheading'] = 'Marketing spots';
$string['marketingspot'] = 'Marketing Spot';
$string['marketingspot1desc'] = 'Enter the Marketing Spot 1 block content either language key or text here.For ex: lang:display or Display';
$string['marketingspot2desc'] = 'Enter the Marketing Spot 2 block content either language key or text here.For ex: lang:display or Display';
$string['aboutustxt'] = 'About Us';
$string['marketingSpot1_status'] = 'Activate this block ';
$string['marketingSpot1_statusdesc'] = 'If you wish to disable this block on front page, uncheck the checkbox <i>Activate this block</i>.';
$string['title'] = 'Title';
$string['description'] = 'Description';
$string['mspottitledesc'] = 'Enter the block title as plain text or lang:language_key for multi-lingual support.<br> You can find the theme language keys here: /theme/enlightlite/lang/en/theme_enlightlite.php. <br/>You can find the default language keys here : /theme/enlightlite/lang[FOLDER].';
$string['button'] = 'Button';
$string['text'] = 'Text';
$string['mspot2urltxtdesc'] = 'Use this option to set the text for button. If you do not want to have button set this option to blank. Enter the button text as plain text or lang:language_key for multi-lingual support. You can find the theme language keys here: /theme/enlightlite/lang/en/theme_enlightlite.php';
$string['mspot2urldesc'] = 'Use this option to set the link for button.';
$string['links'] = 'Links';
$string['link'] = 'Link';
$string['target'] = 'Target';
$string['mspot2urltarget_desc'] = "Use this option to set the link target for button.";
$string['mspotdescdesc'] = 'Enter the description as plain text or lang:language_key for multi-lingual support.<br> You can find the theme language keys here: /theme/enlightlite/lang/en/theme_enlightlite.php.';
$string['mspotmediadesc'] = 'Insert an image or content.';
$string['media'] = 'Media';
$string['learntitle'] = "LEARN ANYTIME, ANYWHERE";
$string["marketingSpot2_status"] = "Activate this block ";
$string["marketingSpot2_statusdesc"] = ": If you wish to disable this block on front page, uncheck the checkbox <i>Activate this block</i>.";
$string['footerheading'] = 'Footer blocks';
$string['footerblock'] = 'Footer Block';
$string['activateblock'] = "Activate this block";
$string['footerb1_status'] = 'Footer Block1 Display Option';
$string['footerb1_statusdesc'] = 'If you wish to disable this block on footer section, uncheck the checkbox <i>Activate this block</i>.';
$string['footerb2_status'] = 'Footer Block2 Display Option';
$string['footerb2_statusdesc'] = '';
$string['footerb3_status'] = 'Footer Block3 Display Option';
$string['footerb3_statusdesc'] = '';
$string['footerb4_status'] = 'Footer Block4 Display Option';
$string['footerb4_statusdesc'] = '';
$string['footerbtitledesc'] = 'Enter a title for this block as plain text or lang:language_key for multi-lingual support. You can find the theme language keys here: /theme/enlightlite/lang/en/theme_enlightlite.php';
$string['footnote'] = "Footnote";
$string['courses'] = "Courses";
$string['footerdescription_desc'] = "A brief description in the context of the block title, for multi-lingual support enter lang:language_key.";
$string['search_courses'] = "Search Your Courses";
$string['footerblink1default'] = '<div><p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut et lobortis diam.&nbsp;</p><p>Duis tellus enim, vestibulum eget varius id, vulputate et mi. Nullam feugiat, diam quis interdum varius</p></div><a href="#"><span style="color: #fff; font-weight: bold; border-bottom: 1px solid #fff">Start Learning Now</span></a>';
$string['footerblink_desc'] = 'You can configure Footer Block{$a->blockno} Links here to be shown by themes.Each line consists of some menu text (lang:language_key or just plain text) , a link URL separated by pipe characters. For example: <pre> lang:moodlecommunity|https://moodle.org
Moodle Support|https://moodle.org/support </pre>';
$string['footerblink2default'] = 'Future students|http://www.example.com/
International students |http://www.example.com/
Researchers|http://www.example.com/';
$string['footerblink3default'] = 'Accessibility|http://www.example.com/
Contact us|http://www.example.com/
Jobs|http://www.example.com/';
$string['socialmediadesc'] = '<strong>This block contains social media icons</strong>';
$string["address"] = "Address";
$string['address_desc'] = "You may enter your address.";
$string["defaultaddress"] = "20-A , Nehru Street , Sathyamoorthi Nagar Madurai - 625010 , Tamilnadu , India.";
$string["emailid"] = "E-mail";
$string['email_desc'] = "You may enter your email.";
$string["defaultemailid"] = "yourmailid@example.com";
$string["phoneno"] = "Phone Number";
$string["defaultphoneno"] = "+123456789";
$string['footphone_desc'] = 'You may enter your phone number.';
$string['socialicon'] = 'Social Media Icon';
$string['socialicon1default'] = 'twitter';
$string['socialicon2default'] = 'google-plus';
$string['socialicon3default'] = 'pinterest-p';
$string['socialicon4default'] = 'facebook-f';
$string['socialicondesc'] = 'Enter the name of the icon you wish to use.  List is <a href="http://fortawesome.github.io/Font-Awesome/cheatsheet/" target="_new">here</a>. Just enter what is after the "fa-".';
$string['siconbgcdesc'] = 'Change the colours on the Social Media Icons Background color';
$string['siconurldesc'] = 'The Social Media url of your organisation';

$string['siconurl'] = 'Social Media Icon Url';
$string['siconurl1default'] = 'https://twitter.com/yourtwittername';
$string['siconurl2default'] = 'https://www.google.com/+yourgoogleplusid';
$string['siconurl3default'] = 'https://in.pinterest.com/yourpinterestname/';
$string['siconurl4default'] = 'https://www.facebook.com/yourfacebookid';
$string['siconurldesc'] = 'The Social Media url of your organisation';
$string['socialicondesc'] = 'Enter the name of the icon you wish to use.  List is <a href="http://fortawesome.github.io/Font-Awesome/cheatsheet/" target="_new">here</a>. Just enter what is after the "fa-".';
$string['socialmediadesc'] = '<strong>This block contains social media icons</strong>';
$string['socialicon'] = 'Social Media Icon';
$string['socialicon1default'] = 'twitter';
$string['socialicon2default'] = 'google-plus';
$string['socialicon3default'] = 'pinterest-p';
$string['socialicon4default'] = 'facebook-f';
$string['siconbgc1default'] = '#47caf6';
$string['siconbgc2default'] = '#e84c3d';
$string['siconbgc3default'] = '#cd2129';
$string['siconbgc4default'] = '#3598dc';
$string['url'] = 'Url';
$string['home'] = 'Home';
$string['bgcolor'] = 'Background Color';
$string['copyrightheading'] = 'Change copyright information';
$string['copyright'] = 'Copyright content';
$string['copyrightdefault'] = 'Copyright &copy; 2017 - Developed by <a href="http://lmsace.com">LMSACE.com</a>. Powered by <a href="https://moodle.org">Moodle</a>';
$string['copyrightdesc'] = 'Enter the copyright information as plain text or lang:language_key for multi-lingual support (Ex <b>lang:information</b>). <br/>You can find the default ';
$string['typesearch'] = "Type and press Search";
